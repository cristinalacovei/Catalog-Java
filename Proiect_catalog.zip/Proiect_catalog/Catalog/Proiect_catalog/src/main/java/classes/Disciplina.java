package classes;

public class Disciplina {
    private int idDisciplina;
    private String nume;

    public Disciplina(int idDisciplina,String nume) {
        this.idDisciplina=idDisciplina;
        this.nume=nume;
    }
    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

}
