package classes;

import java.util.Date;

public class Nota {

    private int idNota;
    private Date dataNota;
    private int idDisciplina;
    private int idElev;
    private int nota;

    public Nota(int idNota, Date dataNota, int idDisciplina, int idElev, int nota) {
        this.idNota = idNota;
        this.dataNota = dataNota;
        this.idDisciplina = idDisciplina;
        this.idElev = idElev;
        this.nota = nota;
    }


    public int getIdNota() {
        return idNota;
    }

    public void setIdNota(int idNota) {
        this.idNota = idNota;
    }

    public Date getDataNota() {
        return dataNota;
    }

    public void setDataNota(Date dataNota) {
        this.dataNota = dataNota;
    }

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    public int getIdElev() {
        return idElev;
    }

    public void setIdElev(int idElev) {
        this.idElev = idElev;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }


}