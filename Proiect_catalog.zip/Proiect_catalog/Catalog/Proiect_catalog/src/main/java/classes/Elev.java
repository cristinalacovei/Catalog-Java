package classes;

public class Elev {

    private int idElev;
    private String nume;

    public Elev(int idElev, String nume) {
        this.idElev = idElev;
        this.nume = nume;
    }


    public int getIdElev() {
        return idElev;
    }

    public void setIdElev(int idElev) {
        this.idElev = idElev;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }
}
