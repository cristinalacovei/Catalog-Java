package classes;

public class Profesor {
    private int idProfesor;
    private int idDisciplina;
    private String nume;

    public Profesor(int idProfesor, int idDisciplina, String nume) {
        this.idProfesor = idProfesor;
        this.idDisciplina = idDisciplina;
        this.nume = nume;
    }
    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }
}
