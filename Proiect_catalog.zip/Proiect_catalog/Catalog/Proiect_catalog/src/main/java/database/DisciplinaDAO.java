package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DisciplinaDAO {
    public static List<String> getAllDiscipline() {
        List<String> discipline = new ArrayList<>();

        // Declarație SQL pentru a obține toate disciplinele
        String selectAllDiscipline = "SELECT nume_disciplina FROM Disciplina";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectAllDiscipline);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Procesează rezultatele și adaugă disciplinele în lista
            while (resultSet.next()) {
                String numeDisciplina = resultSet.getString("nume_disciplina");
                discipline.add(numeDisciplina);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return discipline;
    }
}
