package database;

public class ProfesorDAO {
}
