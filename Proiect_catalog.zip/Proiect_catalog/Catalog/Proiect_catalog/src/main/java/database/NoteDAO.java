package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NoteDAO {
    public static List<Integer> getNoteByIdDisciplinaAndIdElev(int idDisciplina, int idElev) {
        List<Integer> note = new ArrayList<>();

        // Declarație SQL pentru a obține notele pentru o anumită disciplină și un anumit elev
        String selectNote = "SELECT nota FROM Note WHERE id_disciplina = ? AND id_elev = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectNote)) {

            // Setează valorile pentru parametrii din query
            preparedStatement.setInt(1, idDisciplina);
            preparedStatement.setInt(2, idElev);

            // Execută query-ul și obține rezultatele
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Procesează rezultatele și adaugă notele în lista
                while (resultSet.next()) {
                    int nota = resultSet.getInt("nota");
                    note.add(nota);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return note;
    }
}
