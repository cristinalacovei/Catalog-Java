package database;
import classes.Elev;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ElevDAO {
    public static List<Elev> getAllElevi() {
        List<Elev> elevi = new ArrayList<>();

        // Declarațiile SQL
        String selectAllElevi = "SELECT * FROM Elevi";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectAllElevi);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Procesează rezultatele și adaugă elevii în lista
            while (resultSet.next()) {
                int idElev = resultSet.getInt("id_elev");
                String numeElev = resultSet.getString("nume");

                Elev elev = new Elev(idElev, numeElev);
                elevi.add(elev);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elevi;
    }

    public static int getIdElev(String nume) {
        return 0;
    }


}
