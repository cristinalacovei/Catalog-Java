package main;

import classes.Elev;
import database.ElevDAO;
import database.DisciplinaDAO;
import database.NoteDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


public class MainClass {

    public static void main(String[] args) {
        // Creați un frame (fereastra) Swing
        JFrame frame = new JFrame("Selectează Tipul de Utilizator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Creați eticheta și butoanele
        JLabel label = new JLabel("Selectează tipul de utilizator:");
        JButton elevButton = new JButton("Elev");
        JButton profesorButton = new JButton("Profesor");

        // Adăugați acțiuni pentru butoane
        elevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleElevButtonClick();
            }
        });

        profesorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleProfesorButtonClick();
            }
        });

        // Creați un panou și adăugați componentele în panou
        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(elevButton);
        panel.add(profesorButton);

        // Adăugați panoul la frame și faceți frame-ul vizibil
        frame.add(panel);
        frame.setVisible(true);
    }

    private static void handleElevButtonClick() {
        // Obține lista de elevi din baza de date
        List<Elev> totiElevii = ElevDAO.getAllElevi();

        // Obține lista de discipline
        List<String> discipline = DisciplinaDAO.getAllDiscipline();

        // Crează un frame pentru lista de elevi și note
        JFrame listaEleviFrame = new JFrame("Lista de Elevi și Note");
        listaEleviFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Creează modelul pentru tabel
        DefaultTableModel modelTabel = new DefaultTableModel();
        modelTabel.addColumn("Nume");

        // Adaugă coloane pentru fiecare disciplină
        for (String disciplina : discipline) {
            modelTabel.addColumn(disciplina);
        }

        // Adaugă datele din lista de elevi în modelul tabelului
        for (Elev elev : totiElevii) {
            Object[] rand = new Object[1 + discipline.size()]; // Un rând pentru nume + câte o celulă pentru fiecare disciplină

            rand[0] = elev.getNume(); // Adaugă numele în primul element al rândului
            
            // Adaugă rândul în modelul tabelului
            modelTabel.addRow(rand);
        }

        // Creează tabelul utilizând modelul
        JTable tabel = new JTable(modelTabel);

        // Adaugă tabelul la un JScrollPane pentru a permite derularea
        JScrollPane scrollPane = new JScrollPane(tabel);

        // Adaugă JScrollPane la frame
        listaEleviFrame.add(scrollPane);

        // Ajustează dimensiunea preferată pentru JScrollPane
        scrollPane.setPreferredSize(new Dimension(500, 300));

        // Face frame-ul vizibil
        listaEleviFrame.pack();
        listaEleviFrame.setVisible(true);
    }
    private static void handleProfesorButtonClick() {
        // Deschide fereastra pentru aplicația profesorului
        System.out.println("Utilizatorul a ales să fie profesor");
        // Aici ar trebui să deschizi fereastra pentru aplicația profesorului
    }
}
