package main;

import classes.Elev;
import classes.Profesor;
import database.ElevDAO;
import database.DisciplinaDAO;
import database.NoteDAO;
import database.ProfesorDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static database.DisciplinaDAO.getDisciplinaById;
import static database.NoteDAO.calculeazaMedieFinala;
import static database.ProfesorDAO.getAllProfesori;
import static database.ProfesorDAO.getProfesorByIdDisciplina;


public class MainClass {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Selectează Tipul de Utilizator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Creare panou principal
        JPanel mainPanel = new JPanel(new GridBagLayout());

        // Creare GridBagConstraints pentru a controla amplasarea componentelor
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Margini între componente

        // Creare etichetă și setare proprietăți
        JLabel label = new JLabel("Selectează tipul de utilizator:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(label, gbc);

        // Creare butoane și setare proprietăți
        JButton elevButton = createButton("Elev");
        gbc.gridx = 0;
        gbc.gridy = 1;
        mainPanel.add(elevButton, gbc);

        JButton profesorButton = createButton("Profesor");
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(profesorButton, gbc);

        // Adăugare acțiuni pentru butoane
        elevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleElevButtonClick();
            }
        });

        profesorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleProfesorButtonClick();
            }
        });

        // Setare culoare de fundal pentru panoul principal
        mainPanel.setBackground(new Color(200, 255, 247));

        // Adăugare panou principal la frame și setare proprietăți
        frame.getContentPane().add(mainPanel, BorderLayout.CENTER);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null); // Afișare în mijlocul ecranului
        frame.setVisible(true);
    }
    private static JTextField textFieldMedia = new JTextField(10);
    private static JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(206, 200, 255));
        return button;
    }
    private static void handleElevButtonClick() {
        String[] options = {"Vizualizează Elevii", "Vizualizează Profesorii", "Vizualizează Date Elev"," Afisare Medie Elev "};
        int choice = JOptionPane.showOptionDialog(null, "Alege opțiunea", "Alege Tipul", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            List<Elev> elevi = ElevDAO.getAllElevi();
            afiseazaListaElevi(elevi);
        } else if (choice == 1) {
            List<Profesor> profesori=getAllProfesori();
            afiseazaListaProfesori(profesori);
        }
        else if (choice == 2)
        {
            vizualizareDateElev();
        }
        else if(choice==3)
        {
            afisareMedieElev();
        }
    }

    private static void afiseazaListaProfesori(List<Profesor> profesori) {
        // Creează un frame pentru lista de profesori și discipline
        JFrame listaProfesoriFrame = new JFrame("Lista de Profesori și Discipline");
        listaProfesoriFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Creează modelul pentru tabel
        DefaultTableModel modelTabel = new DefaultTableModel();
        modelTabel.addColumn("Nume Profesor");
        modelTabel.addColumn("Disciplina");

        // Adaugă datele din lista de profesori în modelul tabelului
        for (Profesor profesor : profesori) {
            Object[] rand = new Object[2]; // Un rând pentru nume profesor și disciplină

            rand[0] = profesor.getNume(); // Adaugă numele profesorului în primul element al rândului

            // Găsește numele disciplinei folosind idDisciplina profesorului
            String disciplinaProfesor = getDisciplinaById(profesor.getIdDisciplina());

            rand[1] = disciplinaProfesor; // Adaugă numele disciplinei în al doilea element al rândului

            // Adaugă rândul în modelul tabelului
            modelTabel.addRow(rand);
        }

        // Creează tabelul utilizând modelul
        JTable tabel = new JTable(modelTabel);

        // Adaugă tabelul la un JScrollPane pentru a permite derularea
        JScrollPane scrollPane = new JScrollPane(tabel);

        // Adaugă JScrollPane la frame
        listaProfesoriFrame.add(scrollPane);

        // Ajustează dimensiunea preferată pentru JScrollPane
        scrollPane.setPreferredSize(new Dimension(500, 300));

        // Face frame-ul vizibil
        listaProfesoriFrame.pack();
        listaProfesoriFrame.setVisible(true);
    }

    private static void afiseazaListaElevi(List<Elev> elevi) {
        // Obține lista de discipline
        List<String> discipline = DisciplinaDAO.getAllDiscipline();

        // Creează un frame pentru lista de elevi și note
        JFrame listaEleviFrame = new JFrame("Lista de Elevi și Note");
        listaEleviFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Creează modelul pentru tabel
        DefaultTableModel modelTabel = new DefaultTableModel();
        modelTabel.addColumn("Nume");

        // Adaugă coloane pentru fiecare disciplină
        for (String disciplina : discipline) {
            modelTabel.addColumn(disciplina);
        }

        // Adaugă datele din lista de elevi în modelul tabelului
        for (Elev elev : elevi) {
            Object[] rand = new Object[1 + discipline.size()]; // Un rând pentru nume + câte o celulă pentru fiecare disciplină

            rand[0] = elev.getNume(); // Adaugă numele în primul element al rândului

            // Obține notele pentru fiecare disciplină și adaugă-le în rând
            for (int i = 0; i < discipline.size(); i++) {
                // Obține notele pentru disciplina curentă și elevul curent
                List<Integer> note = NoteDAO.getNoteByIdDisciplinaAndIdElev(i+1, elev.getIdElev()); // Folosește getIdElev()

                // Transformă lista de note într-un șir de caractere de forma "10, 7, 8...
                String noteString = note.stream().map(Object::toString).collect(Collectors.joining(", "));

                // Adaugă șirul de note în rândul corespunzător disciplinei
                rand[i + 1] = noteString;
            }

            // Adaugă rândul în modelul tabelului
            modelTabel.addRow(rand);
        }

        // Creează tabelul utilizând modelul
        JTable tabel = new JTable(modelTabel);

        // Adaugă tabelul la un JScrollPane pentru a permite derularea
        JScrollPane scrollPane = new JScrollPane(tabel);

        // Adaugă JScrollPane la frame
        listaEleviFrame.add(scrollPane);

        // Ajustează dimensiunea preferată pentru JScrollPane
        scrollPane.setPreferredSize(new Dimension(500, 300));

        // Face frame-ul vizibil
        listaEleviFrame.pack();
        listaEleviFrame.setVisible(true);
    }
    private static void vizualizareDateElev() {
        // Obține lista elevilor pentru disciplina dată
        List<Elev> eleviDisciplina = ElevDAO.getAllElevi();

        // Creează un array cu numele elevilor pentru JOptionPane
        String[] numeElevi = eleviDisciplina.stream().map(Elev::getNume).toArray(String[]::new);

        // Afișează un dialog de selecție pentru a alege un elev
        String elevSelectat = (String) JOptionPane.showInputDialog(null, "Alege elevul pentru adăugarea notei:",
                "Alege Elev", JOptionPane.QUESTION_MESSAGE, null, numeElevi, numeElevi[0]);

        // Verifică dacă s-a selectat un elev
        if (elevSelectat != null && !elevSelectat.isEmpty()) {
            // Obține lista disciplinelor pentru elevul dat
            List<String> disciplineElev = DisciplinaDAO.getAllDiscipline();

            // Creează un array cu numele disciplinelor pentru JOptionPane
            String[] numeDiscipline = disciplineElev.toArray(new String[0]);

            // Afișează un dialog de selecție pentru a alege o disciplină
            String disciplinaSelectata = (String) JOptionPane.showInputDialog(null, "Alege disciplina:",
                    "Alege Disciplina", JOptionPane.QUESTION_MESSAGE, null, numeDiscipline, numeDiscipline[0]);

            if (disciplinaSelectata != null && !disciplinaSelectata.isEmpty()) {
                // Obține lista de note pentru elevul și disciplina selectate
                int idElev = ElevDAO.getIdElev(elevSelectat);
                int idDisciplina = DisciplinaDAO.getIdDisciplina(disciplinaSelectata);
                List<NoteDAO.NotaData> noteElevDisciplina = NoteDAO.getNoteAndDataByIdDisciplinaAndIdElev(idDisciplina, idElev);

                // Creează modelul pentru tabel
                DefaultTableModel modelTabel = new DefaultTableModel();
                modelTabel.addColumn("Data");
                modelTabel.addColumn("Nota");

                // Adaugă datele în modelul tabelului
                for (NoteDAO.NotaData nota : noteElevDisciplina) {
                    Object[] rand = {nota.getData(), nota.getNota()};
                    modelTabel.addRow(rand);
                }

                // Creează tabelul utilizând modelul
                JTable tabel = new JTable(modelTabel);

                // Afișează tabelul într-un JScrollPane
                JOptionPane.showMessageDialog(null, new JScrollPane(tabel), "Note Elev", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    private static void afisareMedieElev() {
        // Obține lista elevilor pentru disciplina dată
        List<Elev> eleviDisciplina = ElevDAO.getAllElevi();

        // Creează un array cu numele elevilor pentru JOptionPane
        String[] numeElevi = eleviDisciplina.stream().map(Elev::getNume).toArray(String[]::new);

        // Afișează un dialog de selecție pentru a alege un elev
        String elevSelectat = (String) JOptionPane.showInputDialog(null, "Alege elevul pentru adăugarea notei:",
                "Alege Elev", JOptionPane.QUESTION_MESSAGE, null, numeElevi, numeElevi[0]);

        // Verifică dacă s-a selectat un elev
        if (elevSelectat != null && !elevSelectat.isEmpty()) {
            // Obține lista disciplinelor pentru elevul dat
            List<String> disciplineElev = DisciplinaDAO.getAllDiscipline();

            // Creează un array cu numele disciplinelor pentru JOptionPane
            String[] numeDiscipline = disciplineElev.toArray(new String[0]);

            // Afișează un dialog de selecție pentru a alege o disciplină
            String disciplinaSelectata = (String) JOptionPane.showInputDialog(null, "Alege disciplina:",
                    "Alege Disciplina", JOptionPane.QUESTION_MESSAGE, null, numeDiscipline, numeDiscipline[0]);

            if (disciplinaSelectata != null && !disciplinaSelectata.isEmpty()) {
                // Obține lista de note pentru elevul și disciplina selectate
                int idElev = ElevDAO.getIdElev(elevSelectat);
                int idDisciplina = DisciplinaDAO.getIdDisciplina(disciplinaSelectata);
                double medieFinala = calculeazaMedieFinala(idDisciplina, idElev);
                // Afișează media finală într-un dialog
                JOptionPane.showMessageDialog(null, "Media finală pentru elevul " + elevSelectat + " la materia " + getDisciplinaById(idDisciplina) + ": " + medieFinala);
            }
        }
    }


    private static void handleProfesorButtonClick() {
        // Obține numele profesorului
        String numeProfesor = JOptionPane.showInputDialog("Introduceți numele profesorului:");

        // Obține profesorul în funcție de nume
        Profesor profesor = ProfesorDAO.getProfesorByNume(numeProfesor);

        if (profesor != null) {
            // Creați un frame (fereastra) Swing pentru profesor
            JFrame frameProfesor = new JFrame("Aplicație Profesor: " + profesor.getNume());
            frameProfesor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frameProfesor.setSize(600, 400);

            // Creați butoanele pentru funcționalitățile specifice
            JButton adaugaNotaButton = new JButton("Adaugă Notă");
            JButton afisareAlfabeticEleviButton = new JButton("Afișare Elevi Alfabetic");
            JButton afisareAlfabeticProfesoriButton = new JButton("Afișare Profesori Alfabetic");
            JButton calculeazaMedieFinalaButton = new JButton("Calculează Medie Finală");
            JButton sortareEleviMedie = new JButton("Sorteaza elevii in functie de medie");

            // Adăugați funcționalitățile pentru fiecare buton
            adaugaNotaButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adaugaNotaDialog(profesor.getIdDisciplina()); // -1 pentru a indica că nu se selectează un elev specific
                }
            });

            afisareAlfabeticEleviButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Obține lista de elevi sortată alfabetic
                    List<Elev> eleviAlfabetic = ElevDAO.getAllEleviSortedAlphabetically();

                    // Implementează codul pentru afișarea listei de elevi în ordine alfabetică
                    afiseazaListaElevi(eleviAlfabetic);
                }
            });

            afisareAlfabeticProfesoriButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Obține lista de profesori sortată alfabetic
                    List<Profesor> profesoriAlfabetic = ProfesorDAO.getAllProfesoriSortedAlphabetically();

                    // Implementează codul pentru afișarea listei de profesori în ordine alfabetică
                    afiseazaListaProfesori(profesoriAlfabetic);
                }
            });

            calculeazaMedieFinalaButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Afișează un dialog pentru a selecta elevul
                    String[] numeElevi = ElevDAO.getAllElevi().stream().map(Elev::getNume).toArray(String[]::new);
                    String elevSelectat = (String) JOptionPane.showInputDialog(null, "Alege elevul pentru calculul mediei finale:",
                            "Alege Elev", JOptionPane.QUESTION_MESSAGE, null, numeElevi, numeElevi[0]);

                    if (elevSelectat != null) {
                        // Obține id-ul elevului ales
                        int idElevAles = ElevDAO.getAllElevi().stream()
                                .filter(elev -> elev.getNume().equals(elevSelectat))
                                .findFirst().orElseThrow().getIdElev();

                        // Obține id-ul disciplinei pentru profesor
                        int idDisciplinaProfesor = profesor.getIdDisciplina();

                        // Calculează media finală pentru elev și disciplină
                        double medieFinala = calculeazaMedieFinala(idDisciplinaProfesor, idElevAles);
                                // Afișează media finală într-un dialog
                        JOptionPane.showMessageDialog(null, "Media finală pentru elevul " + elevSelectat + " la materia " + getDisciplinaById(idDisciplinaProfesor) + ": " + medieFinala);

                    }
                }
            });

            sortareEleviMedie.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Creare casetă de dialog pentru introducerea mediei dorite
                    JPanel panel = new JPanel();
                    JLabel label = new JLabel("Introduceți media dorită:");
                    JTextField textFieldMedia = new JTextField(10);
                    panel.add(label);
                    panel.add(textFieldMedia);

                    // Afișare casetă de dialog și așteptare până când utilizatorul introduce date
                    int result = JOptionPane.showConfirmDialog(null, panel, "Sortare după medie", JOptionPane.OK_CANCEL_OPTION);

                    // Verificare dacă utilizatorul a apăsat OK
                    if (result == JOptionPane.OK_OPTION) {
                        // Obținerea valorii introduse în caseta text
                        String mediaText = textFieldMedia.getText();

                        // Verificare dacă s-a introdus o valoare validă
                        if (!mediaText.isEmpty()) {
                            try {
                                // Convertirea textului într-o valoare numerică
                                double medieDorita = Double.parseDouble(mediaText);

                                // Filtrare și sortare a elevilor cu media mai mare decât medieDorita
                                List<Elev> eleviFiltrati = ElevDAO.getEleviInFunctieDeMedie(profesor.getIdDisciplina(), medieDorita);

                                // Sortare lista de elevi în ordine descrescătoare după medie
                                eleviFiltrati.sort(Comparator.comparingDouble(
                                        (Elev elev) -> NoteDAO.calculeazaMedieFinala(profesor.getIdDisciplina(), elev.getIdElev())
                                ).reversed());

                                if (!eleviFiltrati.isEmpty()) {
                                    // Obține lista de note pentru elevul și disciplina selectate

                                    // Creează modelul pentru tabel
                                    DefaultTableModel modelTabel = new DefaultTableModel();
                                    modelTabel.addColumn("Elev");
                                    modelTabel.addColumn("Media");

                                    // Adaugă datele în modelul tabelului
                                    for (Elev elev : eleviFiltrati) {
                                        Object[] rand = {elev.getNume(), NoteDAO.calculeazaMedieFinala(profesor.getIdDisciplina(), elev.getIdElev())};
                                        modelTabel.addRow(rand);
                                    }

                                    // Creează tabelul utilizând modelul
                                    JTable tabel = new JTable(modelTabel);
                                    // Afișează tabelul într-un JScrollPane
                                    JOptionPane.showMessageDialog(null, new JScrollPane(tabel), "Elevii cu notă mai mare decât " + medieDorita, JOptionPane.INFORMATION_MESSAGE);
                                }

                            } catch (NumberFormatException ex) {
                                // Afișează un mesaj de eroare dacă nu s-a introdus o valoare numerică validă
                                JOptionPane.showMessageDialog(null, "Introduceți o valoare numerică validă pentru medie.", "Eroare", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            // Afișează un mesaj de eroare dacă caseta text este goală
                            JOptionPane.showMessageDialog(null, "Introduceți o valoare pentru medie.", "Eroare", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            });





            // Adăugați butoanele la frame
            frameProfesor.setLayout(new FlowLayout());
            frameProfesor.add(adaugaNotaButton);
            frameProfesor.add(afisareAlfabeticEleviButton);
            frameProfesor.add(afisareAlfabeticProfesoriButton);
            frameProfesor.add(calculeazaMedieFinalaButton);
            frameProfesor.add(sortareEleviMedie);

            // Face frame-ul vizibil
            frameProfesor.setVisible(true);
        }
    }

    private static void adaugaNotaDialog(int idDisciplina) {
        // Obține lista elevilor pentru disciplina dată
        List<Elev> eleviDisciplina = ElevDAO.getAllElevi();

        // Creează un array cu numele elevilor pentru JOptionPane
        String[] numeElevi = eleviDisciplina.stream().map(Elev::getNume).toArray(String[]::new);

        // Afișează un dialog de selecție pentru a alege un elev
        String elevSelectat = (String) JOptionPane.showInputDialog(null, "Alege elevul pentru adăugarea notei:",
                "Alege Elev", JOptionPane.QUESTION_MESSAGE, null, numeElevi, numeElevi[0]);

        if (elevSelectat != null) {
            // Obține id-ul elevului ales
            int idElevAles = eleviDisciplina.stream()
                    .filter(elev -> elev.getNume().equals(elevSelectat))
                    .findFirst().orElseThrow().getIdElev();

            String notaStr = JOptionPane.showInputDialog("Introduceți nota pentru elev:");

            try {
                int nota = Integer.parseInt(notaStr);

                // Validarea notei
                if (nota < 1 || nota > 10) {
                    JOptionPane.showMessageDialog(null, "Introduceți o valoare între 1 și 10 pentru nota.", "Eroare", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Adaugă nota în baza de date
                    NoteDAO.adaugaNota(idDisciplina, idElevAles, nota);

                    // Afișează mesaj de succes
                    JOptionPane.showMessageDialog(null, "Nota a fost adăugată cu succes!");

                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Introduceți o valoare numerică validă pentru nota.", "Eroare", JOptionPane.ERROR_MESSAGE);
            }

        }
    }
}
