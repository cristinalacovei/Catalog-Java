package database;

import classes.Profesor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ProfesorDAO {
    public static List<Profesor> getAllProfesori() {
        List<Profesor> totiProfesorii = new ArrayList<>();

        // Declarație SQL pentru a obține toți profesorii
        String selectAllProfesori = "SELECT id_profesor, id_disciplina, nume_profesor FROM Profesor";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectAllProfesori);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Procesează rezultatele și adaugă profesorii în lista
            while (resultSet.next()) {
                int idProfesor = resultSet.getInt("id_profesor");
                int idDisciplina = resultSet.getInt("id_disciplina");
                String numeProfesor = resultSet.getString("nume_profesor");

                Profesor profesor = new Profesor(idProfesor, idDisciplina, numeProfesor);
                totiProfesorii.add(profesor);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totiProfesorii;
    }
    public static Profesor getProfesorByNume(String numeProfesor) {
        Profesor profesor = null;

        // Declarație SQL pentru a obține profesorul după nume
        String selectProfesorByNume = "SELECT id_profesor, id_disciplina, nume_profesor FROM Profesor WHERE nume_profesor = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectProfesorByNume)) {

            preparedStatement.setString(1, numeProfesor);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Dacă există un profesor cu numele specificat, creează obiectul Profesor
                if (resultSet.next()) {
                    int idProfesor = resultSet.getInt("id_profesor");
                    int idDisciplina = resultSet.getInt("id_disciplina");
                    String nume = resultSet.getString("nume_profesor");

                    // Modificare: Profesorul are acum o singură disciplină
                    profesor = new Profesor(idProfesor, idDisciplina, nume);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return profesor;
    }

    public static Profesor getProfesorByIdDisciplina(int idDisciplina) {
        Profesor profesor = null;

        // Declarație SQL pentru a obține profesorul pentru o anumită disciplină
        String selectProfesorByIdDisciplina = "SELECT id_profesor, nume FROM Profesor " +
                "WHERE id_profesor IN (SELECT id_profesor FROM Inscriere WHERE id_disciplina = ?)";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectProfesorByIdDisciplina)) {

            // Setează valoarea pentru parametrul din query
            preparedStatement.setInt(1, idDisciplina);

            // Execută query-ul și obține rezultatele
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Verifică dacă există rezultate
                if (resultSet.next()) {
                    int idProfesor = resultSet.getInt("id_profesor");
                    String numeProfesor = resultSet.getString("nume");

                    // Creează un obiect Profesor și atribuie-l variabilei profesor
                    profesor = new Profesor(idProfesor, idDisciplina, numeProfesor);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return profesor;
    }

    public static List<Profesor> getAllProfesoriSortedAlphabetically() {
        List<Profesor> profesori = getAllProfesori();

        // Sortează lista de profesori alfabetic după nume
        profesori.sort(Comparator.comparing(Profesor::getNume));

        return profesori;
    }
}
