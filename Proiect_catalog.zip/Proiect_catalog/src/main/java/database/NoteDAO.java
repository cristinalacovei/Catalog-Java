package database;

import javafx.util.Pair;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class NoteDAO {
    public static List<Integer> getNoteByIdDisciplinaAndIdElev(int idDisciplina, int idElev) {
        List<Integer> note = new ArrayList<>();

        // Declarație SQL pentru a obține notele pentru o anumită disciplină și un anumit elev
        String selectNote = "SELECT nota FROM Note WHERE id_disciplina = ? AND id_elev = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectNote)) {

            // Setează valorile pentru parametrii din query
            preparedStatement.setInt(1, idDisciplina);
            preparedStatement.setInt(2, idElev);

            // Execută query-ul și obține rezultatele
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Procesează rezultatele și adaugă notele în lista
                while (resultSet.next()) {
                    int nota = resultSet.getInt("nota");
                    note.add(nota);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return note;
    }

    public static List<NotaData> getNoteAndDataByIdDisciplinaAndIdElev(int idDisciplina, int idElev) {
        List<NotaData> noteList = new ArrayList<>();

        // Declarație SQL pentru a obține notele pentru o anumită disciplină și un anumit elev
        String selectNote = "SELECT data_nota, nota FROM Note WHERE id_disciplina = ? AND id_elev = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectNote)) {

            // Setează valorile pentru parametrii din query
            preparedStatement.setInt(1, idDisciplina);
            preparedStatement.setInt(2, idElev);

            // Execută query-ul și obține rezultatele
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Procesează rezultatele și adaugă notele în lista
                while (resultSet.next()) {
                    Date dataNota = resultSet.getDate("data_nota");
                    int nota = resultSet.getInt("nota");
                    NotaData notaData = new NotaData(dataNota, nota);
                    noteList.add(notaData);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        // Sortează lista după data notelor în ordine descrescătoare
        noteList.sort(Comparator.comparing(NotaData::getData).reversed());
        return noteList;
    }

    public static void adaugaNota(int idDisciplina, int idElev, int nota) {
        // Declarație SQL pentru a adăuga o notă în baza de date
        String insertNota = "INSERT INTO Note (data_nota, id_disciplina, id_elev, nota) VALUES (NOW(), ?, ?, ?)";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(insertNota)) {

            preparedStatement.setInt(1, idDisciplina);
            preparedStatement.setInt(2, idElev);
            preparedStatement.setInt(3, nota);

            // Execută actualizarea bazei de date
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static double calculeazaMedieFinala(int idDisciplina, int idElev) {
        // Declarație SQL pentru a obține toate notele pentru o anumită disciplină
        String selectNote = "SELECT nota FROM Note WHERE id_disciplina = ? AND id_elev = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectNote)) {

            // Setează valorile pentru parametrii din query
            preparedStatement.setInt(1, idDisciplina);
            preparedStatement.setInt(2, idElev);

            // Execută query-ul și obține rezultatele
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                int numarNote = 0;
                int sumaNote = 0;

                // Procesează rezultatele și calculează suma notelor și numărul de note
                while (resultSet.next()) {
                    int nota = resultSet.getInt("nota");
                    sumaNote += nota;
                    numarNote++;
                }

                // Calculează media finală
                if (numarNote > 0) {
                    return (double) sumaNote / numarNote;
                } else {
                    return 0.0;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return 0.0;
        }
    }

    public static class NotaData {
        private Date data;
        private int nota;

        public NotaData(Date data, int nota) {
            this.data = data;
            this.nota = nota;
        }

        public Date getData() {
            return data;
        }

        public int getNota() {
            return nota;
        }
    }
}