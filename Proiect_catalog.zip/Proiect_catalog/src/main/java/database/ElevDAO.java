package database;
import classes.Elev;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static database.NoteDAO.calculeazaMedieFinala;

public class ElevDAO {
    public static List<Elev> getAllElevi() {
        List<Elev> elevi = new ArrayList<>();

        // Declarațiile SQL
        String selectAllElevi = "SELECT * FROM Elevi";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectAllElevi);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Procesează rezultatele și adaugă elevii în lista
            while (resultSet.next()) {
                int idElev = resultSet.getInt("id_elev");
                String numeElev = resultSet.getString("nume");

                Elev elev = new Elev(idElev, numeElev);
                elevi.add(elev);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elevi;
    }

    public static int getIdElev(String nume) {
        int idElev = -1; // Valoare implicită, în cazul în care nu găsim niciun elev cu acel nume

        // Declarație SQL pentru a obține id-ul elevului după nume
        String selectIdElev = "SELECT id_elev FROM Elevi WHERE nume = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectIdElev)) {

            // Setează valoarea pentru parametrul din query
            preparedStatement.setString(1, nume);

            // Execută query-ul și obține rezultatele
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Verifică dacă există un rezultat
                if (resultSet.next()) {
                    idElev = resultSet.getInt("id_elev");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return idElev;
    }

    public static List<Elev> getAllEleviSortedAlphabetically() {
        List<Elev> elevi = getAllElevi();

        // Sortează lista de elevi alfabetic după nume
        elevi.sort(Comparator.comparing(Elev::getNume));

        return elevi;
    }
    public static List<Elev> getEleviInFunctieDeMedie (int idDisciplina, double medieCifra) {
        // Obține toți elevii
        List<Elev> elevi = getAllElevi();

        // Filtrare: doar elevii cu media mai mare decât medieCifra
        List<Elev> eleviCuMedieMaiMare = elevi.stream()
                .filter(elev -> calculeazaMedieFinala(idDisciplina, elev.getIdElev()) > medieCifra)
                .collect(Collectors.toList());

        return eleviCuMedieMaiMare;
    }
}
