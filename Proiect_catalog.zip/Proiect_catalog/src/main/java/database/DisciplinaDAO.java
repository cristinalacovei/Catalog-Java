package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DisciplinaDAO {
    public static List<String> getAllDiscipline() {
        List<String> discipline = new ArrayList<>();

        // Declarație SQL pentru a obține toate disciplinele
        String selectAllDiscipline = "SELECT nume_disciplina FROM Disciplina";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectAllDiscipline);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Procesează rezultatele și adaugă disciplinele în lista
            while (resultSet.next()) {
                String numeDisciplina = resultSet.getString("nume_disciplina");
                discipline.add(numeDisciplina);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


        return discipline;
    }

    public static String getDisciplinaById(int idDisciplina) {
        String numeDisciplina = "Nedeterminat"; // Valoare implicită, în cazul în care disciplina nu este găsită

        // Declarație SQL pentru a obține numele disciplinei după ID
        String selectDisciplinaById = "SELECT nume_disciplina FROM Disciplina WHERE id_disciplina = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectDisciplinaById)) {

            preparedStatement.setInt(1, idDisciplina);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Dacă există o disciplină cu ID-ul specificat, actualizează numeleDisciplina
                if (resultSet.next()) {
                    numeDisciplina = resultSet.getString("nume_disciplina");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return numeDisciplina;
    }


    public static int getIdDisciplina(String numeDisciplina) {
        int idDisciplina = -1;

        // Declarație SQL pentru a obține ID-ul disciplinei
        String selectIdDisciplina = "SELECT id_disciplina FROM Disciplina WHERE nume_disciplina = ?";

        try (Connection connection = DatabaseConnect.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectIdDisciplina)) {

            preparedStatement.setString(1, numeDisciplina);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    idDisciplina = resultSet.getInt("id_disciplina");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return idDisciplina;
    }
}
